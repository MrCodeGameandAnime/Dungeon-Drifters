"""Authored enemy content."""
