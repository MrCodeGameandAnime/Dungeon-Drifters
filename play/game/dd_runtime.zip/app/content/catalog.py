"""Deterministic runtime access to authored content."""

from app.content._generated_catalog import (
    GENERATED_DRIFTER_SPECS,
    GENERATED_ENCOUNTER_SPECS,
    GENERATED_ENEMY_SPECS,
    GENERATED_ROUTE_SPECS,
    GENERATED_WEAPON_SPECS,
)
from app.content.drifter_spec import DrifterSpec
from app.content.encounter_spec import EncounterSpec
from app.content.enemy_spec import EnemySpec
from app.content.route_spec import RouteSpec
from app.content.weapon_spec import WeaponSpec
from app.enemies.state import EnemyState
from app.enemies.validation import validate_enemy_tier
from app.readonly_mapping import readonly_mapping


def _build_enemy_catalog(records):
    catalog = {}
    ordered_specs = []
    for directory_id, spec in records:
        if not isinstance(directory_id, str):
            raise TypeError("generated enemy directory IDs must be strings")
        if not isinstance(spec, EnemySpec):
            raise TypeError("generated enemy records must contain EnemySpec values")
        if directory_id != spec.archetype_id:
            raise ValueError(
                "enemy directory ID does not match authored archetype ID: "
                f"{directory_id} != {spec.archetype_id}"
            )
        if spec.archetype_id in catalog:
            raise ValueError(f"duplicate enemy archetype: {spec.archetype_id}")
        catalog[spec.archetype_id] = spec
        ordered_specs.append(spec)
    return tuple(ordered_specs), readonly_mapping(catalog)


ENEMY_SPECS, _ENEMY_CATALOG = _build_enemy_catalog(GENERATED_ENEMY_SPECS)


def _build_weapon_catalog(records):
    by_item_id = {}
    by_persistence_key = {}
    ordered_specs = []
    for directory_id, spec in records:
        if not isinstance(directory_id, str):
            raise TypeError("generated weapon directory IDs must be strings")
        if not isinstance(spec, WeaponSpec):
            raise TypeError("generated weapon records must contain WeaponSpec values")
        if directory_id != spec.item_id:
            raise ValueError(
                "weapon directory ID does not match authored item ID: "
                f"{directory_id} != {spec.item_id}"
            )
        if spec.item_id in by_item_id:
            raise ValueError(f"duplicate weapon item ID: {spec.item_id}")
        if spec.persistence_key in by_persistence_key:
            raise ValueError(
                f"duplicate weapon persistence key: {spec.persistence_key}"
            )
        by_item_id[spec.item_id] = spec
        by_persistence_key[spec.persistence_key] = spec
        ordered_specs.append(spec)
    return (
        tuple(ordered_specs),
        readonly_mapping(by_item_id),
        readonly_mapping(by_persistence_key),
    )


WEAPON_SPECS, _WEAPON_CATALOG, _WEAPON_PERSISTENCE_CATALOG = (
    _build_weapon_catalog(GENERATED_WEAPON_SPECS)
)


def _build_drifter_catalog(records):
    by_id = {}
    by_choice = {}
    for directory_id, spec in records:
        if not isinstance(directory_id, str):
            raise TypeError("generated Drifter directory IDs must be strings")
        if not isinstance(spec, DrifterSpec):
            raise TypeError("generated Drifter records must contain DrifterSpec values")
        if directory_id != spec.drifter_id:
            raise ValueError(
                "Drifter directory ID does not match authored Drifter ID: "
                f"{directory_id} != {spec.drifter_id}"
            )
        if spec.drifter_id in by_id:
            raise ValueError(f"duplicate Drifter ID: {spec.drifter_id}")
        if spec.choice in by_choice:
            raise ValueError(f"duplicate Drifter choice: {spec.choice}")
        by_id[spec.drifter_id] = spec
        by_choice[spec.choice] = spec
    ordered = tuple(sorted(by_id.values(), key=lambda spec: int(spec.choice)))
    return ordered, readonly_mapping(by_id), readonly_mapping(by_choice)


DRIFTER_SPECS, _DRIFTER_CATALOG, _DRIFTER_CHOICE_CATALOG = (
    _build_drifter_catalog(GENERATED_DRIFTER_SPECS)
)


def _build_encounter_catalog(records, *, enemy_catalog=None):
    if enemy_catalog is None:
        enemy_catalog = _ENEMY_CATALOG
    by_id = {}
    for directory_id, spec in records:
        if not isinstance(directory_id, str):
            raise TypeError("generated encounter directory IDs must be strings")
        if not isinstance(spec, EncounterSpec):
            raise TypeError(
                "generated encounter records must contain EncounterSpec values"
            )
        if directory_id != spec.encounter_id:
            raise ValueError(
                "encounter directory ID does not match authored encounter ID: "
                f"{directory_id} != {spec.encounter_id}"
            )
        if spec.encounter_id in by_id:
            raise ValueError(f"duplicate encounter ID: {spec.encounter_id}")
        for archetype_id in spec.enemy_archetype_ids:
            if archetype_id not in enemy_catalog:
                raise ValueError(
                    f"encounter {spec.encounter_id!r} references unknown enemy "
                    f"archetype: {archetype_id!r}"
                )
        by_id[spec.encounter_id] = spec
    ordered = tuple(sorted(by_id.values(), key=lambda spec: spec.encounter_id))
    return ordered, readonly_mapping(by_id)


ENCOUNTER_SPECS, _ENCOUNTER_CATALOG = _build_encounter_catalog(
    GENERATED_ENCOUNTER_SPECS
)


def _build_route_catalog(records, *, encounter_catalog=None):
    if encounter_catalog is None:
        encounter_catalog = _ENCOUNTER_CATALOG
    by_id = {}
    nodes_by_id = {}
    successors_by_node_id = {}
    for directory_id, spec in records:
        if not isinstance(directory_id, str):
            raise TypeError("generated route directory IDs must be strings")
        if not isinstance(spec, RouteSpec):
            raise TypeError("generated route records must contain RouteSpec values")
        if directory_id != spec.route_id:
            raise ValueError(
                "route directory ID does not match authored route ID: "
                f"{directory_id} != {spec.route_id}"
            )
        if spec.route_id in by_id:
            raise ValueError(f"duplicate route ID: {spec.route_id}")
        for index, node in enumerate(spec.nodes):
            if node.node_id in nodes_by_id:
                raise ValueError(f"duplicate global route node ID: {node.node_id}")
            if (
                node.encounter_id is not None
                and node.encounter_id not in encounter_catalog
            ):
                raise ValueError(
                    f"route {spec.route_id!r} references unknown encounter: "
                    f"{node.encounter_id!r}"
                )
            nodes_by_id[node.node_id] = node
            successors_by_node_id[node.node_id] = (
                spec.nodes[index + 1].node_id
                if index + 1 < len(spec.nodes)
                else None
            )
        by_id[spec.route_id] = spec
    ordered = tuple(sorted(by_id.values(), key=lambda spec: spec.route_id))
    return (
        ordered,
        readonly_mapping(by_id),
        readonly_mapping(nodes_by_id),
        readonly_mapping(successors_by_node_id),
    )


(
    ROUTE_SPECS,
    _ROUTE_CATALOG,
    _ROUTE_NODE_CATALOG,
    _ROUTE_SUCCESSOR_CATALOG,
) = _build_route_catalog(GENERATED_ROUTE_SPECS)


def get_enemy_spec(archetype_id):
    try:
        return _ENEMY_CATALOG[archetype_id]
    except (KeyError, TypeError) as error:
        raise ValueError(f"unknown enemy archetype: {archetype_id}") from error


def create_enemy_definition(archetype_id, tier=0):
    spec = get_enemy_spec(archetype_id)
    return spec.create_definition(tier=tier)


def create_enemy_state(archetype_id, tier=0):
    tier = validate_enemy_tier(tier)
    return EnemyState(create_enemy_definition(archetype_id, tier=tier), tier=tier)


def get_weapon_spec(item_id):
    try:
        return _WEAPON_CATALOG[item_id]
    except (KeyError, TypeError) as error:
        raise ValueError(f"unknown weapon item ID: {item_id}") from error


def get_weapon_spec_by_persistence_key(persistence_key):
    try:
        return _WEAPON_PERSISTENCE_CATALOG[persistence_key]
    except (KeyError, TypeError) as error:
        raise ValueError(
            f"unknown weapon persistence key: {persistence_key}"
        ) from error


def create_weapon(item_id):
    return get_weapon_spec(item_id).create_weapon()


def create_weapon_from_persistence_key(persistence_key):
    return get_weapon_spec_by_persistence_key(persistence_key).create_weapon()


def get_drifter_spec(drifter_id):
    try:
        return _DRIFTER_CATALOG[drifter_id]
    except (KeyError, TypeError) as error:
        raise ValueError(f"unknown Drifter ID: {drifter_id}") from error


def get_drifter_spec_by_choice(choice):
    try:
        return _DRIFTER_CHOICE_CATALOG[choice]
    except (KeyError, TypeError):
        return None


def create_drifter(drifter_id):
    return get_drifter_spec(drifter_id).create_unselected_character()


def get_route_spec(route_id):
    try:
        return _ROUTE_CATALOG[route_id]
    except (KeyError, TypeError) as error:
        raise ValueError(f"unknown route ID: {route_id}") from error


def get_encounter_spec(encounter_id):
    try:
        return _ENCOUNTER_CATALOG[encounter_id]
    except (KeyError, TypeError) as error:
        raise ValueError(f"unknown encounter ID: {encounter_id}") from error


def get_encounter_rewards(encounter_id):
    encounter = get_encounter_spec(encounter_id)
    enemies = tuple(
        get_enemy_spec(archetype_id)
        for archetype_id in encounter.enemy_archetype_ids
    )
    return (
        sum(enemy.exp_reward for enemy in enemies),
        sum(enemy.gold_reward for enemy in enemies),
    )


def get_route_node_spec(node_id):
    try:
        return _ROUTE_NODE_CATALOG[node_id]
    except (KeyError, TypeError) as error:
        raise ValueError(f"unknown route node ID: {node_id}") from error


def get_route_successor_id(node_id):
    try:
        return _ROUTE_SUCCESSOR_CATALOG[node_id]
    except (KeyError, TypeError) as error:
        raise ValueError(f"unknown route node ID: {node_id}") from error


def get_inspectable_route_node_spec(node_id):
    node = get_route_node_spec(node_id)
    while node is not None:
        if node.encounter_id is not None:
            return node
        successor_id = get_route_successor_id(node.node_id)
        if successor_id is None:
            return None
        node = get_route_node_spec(successor_id)
    return None


def get_inspectable_encounter_spec(node_id):
    node = get_inspectable_route_node_spec(node_id)
    if node is None:
        return None
    return get_encounter_spec(node.encounter_id)


__all__ = [
    "ENEMY_SPECS",
    "ENCOUNTER_SPECS",
    "DRIFTER_SPECS",
    "ROUTE_SPECS",
    "WEAPON_SPECS",
    "create_enemy_definition",
    "create_enemy_state",
    "create_drifter",
    "create_weapon",
    "create_weapon_from_persistence_key",
    "get_enemy_spec",
    "get_encounter_spec",
    "get_encounter_rewards",
    "get_inspectable_encounter_spec",
    "get_inspectable_route_node_spec",
    "get_drifter_spec",
    "get_drifter_spec_by_choice",
    "get_route_spec",
    "get_route_node_spec",
    "get_route_successor_id",
    "get_weapon_spec",
    "get_weapon_spec_by_persistence_key",
]
