"""Goblin Pair encounter content."""
