"""Goblin Shaman encounter content."""
