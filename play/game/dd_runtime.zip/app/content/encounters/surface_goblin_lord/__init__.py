"""Goblin Lord encounter content."""
