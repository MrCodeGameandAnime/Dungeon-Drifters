"""Goblin Ambush encounter content."""
