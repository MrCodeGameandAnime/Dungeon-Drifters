"""Authored encounter content packages."""
