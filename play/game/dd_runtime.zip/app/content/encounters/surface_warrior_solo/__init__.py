"""Goblin Warrior encounter content."""
