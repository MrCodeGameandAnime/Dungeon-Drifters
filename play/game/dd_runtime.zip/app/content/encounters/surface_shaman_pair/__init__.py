"""Shaman Pair encounter content."""
