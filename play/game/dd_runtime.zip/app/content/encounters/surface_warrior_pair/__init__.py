"""Warrior Patrol encounter content."""
