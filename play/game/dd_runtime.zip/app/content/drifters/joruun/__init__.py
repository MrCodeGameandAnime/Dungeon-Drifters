"""Monk authored content."""
