"""Rogue Archer authored content."""
