"""Black Mage authored content."""
