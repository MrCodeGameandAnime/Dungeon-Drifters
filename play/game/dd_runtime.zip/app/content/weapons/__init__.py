"""Authored signature-weapon packages."""
