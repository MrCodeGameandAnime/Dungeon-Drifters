"""Sunder-Spire authored content."""
