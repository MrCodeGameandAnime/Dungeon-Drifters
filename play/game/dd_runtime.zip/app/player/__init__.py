"""Player and character package."""
