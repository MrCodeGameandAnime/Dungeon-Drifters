"""Battle user-interface adapters."""
